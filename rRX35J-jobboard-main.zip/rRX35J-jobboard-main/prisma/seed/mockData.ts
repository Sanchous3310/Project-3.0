import { PrismaClient } from '@prisma/client'

const prisma = new PrismaClient()

const splitSql = (sql: string) => {
  return sql.split(';').filter(content => content.trim() !== '')
}

async function main() {
  const sql = `

INSERT INTO "User" ("id", "email", "name", "pictureUrl", "tokenInvitation", "emailVerified", "status", "globalRole", "password") VALUES ('a64eec48-aed5-4ee7-9bab-7a70fd190f4a', '1Napoleon71@yahoo.com', 'John Doe', 'https://i.imgur.com/YfJQV5z.png?id=3', 'token789ghi', false, 'VERIFIED', 'USER', '$2b$10$ppubsZypHzkqW9dkhMB97ul2.wSsvaCoDE2CzqIHygddRMKXvpYUC');
INSERT INTO "User" ("id", "email", "name", "pictureUrl", "tokenInvitation", "emailVerified", "status", "globalRole", "password") VALUES ('2c93832d-9e09-4a48-a4d8-13768d26a0fe', '10Keara_Dickens@gmail.com', 'John Doe', 'https://i.imgur.com/YfJQV5z.png?id=12', 'abc123xyz', false, 'VERIFIED', 'USER', '$2b$10$ppubsZypHzkqW9dkhMB97ul2.wSsvaCoDE2CzqIHygddRMKXvpYUC');
INSERT INTO "User" ("id", "email", "name", "pictureUrl", "tokenInvitation", "emailVerified", "status", "globalRole", "password") VALUES ('b6ad7d36-2a8e-40b1-ad7e-28a6c085e4a7', '19Maybelle_Bahringer@hotmail.com', 'Jane Smith', 'https://i.imgur.com/YfJQV5z.png?id=21', 'token789ghi', true, 'VERIFIED', 'USER', '$2b$10$ppubsZypHzkqW9dkhMB97ul2.wSsvaCoDE2CzqIHygddRMKXvpYUC');
INSERT INTO "User" ("id", "email", "name", "pictureUrl", "tokenInvitation", "emailVerified", "status", "globalRole", "password") VALUES ('eb913330-0213-4a8b-ac8b-8634014a2e56', '28Eriberto58@hotmail.com', 'John Doe', 'https://i.imgur.com/YfJQV5z.png?id=30', 'abc123xyz', true, 'VERIFIED', 'USER', '$2b$10$ppubsZypHzkqW9dkhMB97ul2.wSsvaCoDE2CzqIHygddRMKXvpYUC');
INSERT INTO "User" ("id", "email", "name", "pictureUrl", "tokenInvitation", "emailVerified", "status", "globalRole", "password") VALUES ('0fb4610a-cbb1-418e-af1a-42a409bbf595', '46Shanelle.Johnson@gmail.com', 'Emily Davis', 'https://i.imgur.com/YfJQV5z.png?id=48', 'abc123xyz', true, 'VERIFIED', 'USER', '$2b$10$ppubsZypHzkqW9dkhMB97ul2.wSsvaCoDE2CzqIHygddRMKXvpYUC');
INSERT INTO "User" ("id", "email", "name", "pictureUrl", "tokenInvitation", "emailVerified", "status", "globalRole", "password") VALUES ('789a56cb-dcb0-4066-933f-1cc03da14de9', '55Lowell92@hotmail.com', 'Alice Johnson', 'https://i.imgur.com/YfJQV5z.png?id=57', 'invitation456def', true, 'VERIFIED', 'USER', '$2b$10$ppubsZypHzkqW9dkhMB97ul2.wSsvaCoDE2CzqIHygddRMKXvpYUC');
INSERT INTO "User" ("id", "email", "name", "pictureUrl", "tokenInvitation", "emailVerified", "status", "globalRole", "password") VALUES ('f008efc6-b911-47ac-836d-a0a045bb9250', '64Hayley15@gmail.com', 'Alice Johnson', 'https://i.imgur.com/YfJQV5z.png?id=66', 'securetoken321mno', false, 'VERIFIED', 'USER', '$2b$10$ppubsZypHzkqW9dkhMB97ul2.wSsvaCoDE2CzqIHygddRMKXvpYUC');
INSERT INTO "User" ("id", "email", "name", "pictureUrl", "tokenInvitation", "emailVerified", "status", "globalRole", "password") VALUES ('1798ced1-19cb-41f0-b598-3a796eac9378', '73Garrison_Hilll56@hotmail.com', 'John Doe', 'https://i.imgur.com/YfJQV5z.png?id=75', 'invitation456def', true, 'VERIFIED', 'USER', '$2b$10$ppubsZypHzkqW9dkhMB97ul2.wSsvaCoDE2CzqIHygddRMKXvpYUC');
INSERT INTO "User" ("id", "email", "name", "pictureUrl", "tokenInvitation", "emailVerified", "status", "globalRole", "password") VALUES ('be94e192-0cc5-47d7-b335-f2d5a93cdf88', '82Devon51@gmail.com', 'Alice Johnson', 'https://i.imgur.com/YfJQV5z.png?id=84', 'token789ghi', false, 'VERIFIED', 'USER', '$2b$10$ppubsZypHzkqW9dkhMB97ul2.wSsvaCoDE2CzqIHygddRMKXvpYUC');

INSERT INTO "Company" ("id", "name", "description", "location", "website", "logoUrl") VALUES ('b311558f-1a62-4b2d-8801-686ae990a01c', 'Global Dynamics', 'A multinational corporation with a diverse portfolio.', 'London UK', 'httpswww.globaldynamics.com', 'https://i.imgur.com/YfJQV5z.png?id=95');
INSERT INTO "Company" ("id", "name", "description", "location", "website", "logoUrl") VALUES ('6cab533e-868c-4d33-8bee-192e6fb95068', 'Future Enterprises', 'A creative agency dedicated to unique and impactful designs.', 'Tokyo Japan', 'httpswww.globaldynamics.com', 'https://i.imgur.com/YfJQV5z.png?id=101');
INSERT INTO "Company" ("id", "name", "description", "location", "website", "logoUrl") VALUES ('48239417-30d7-4d64-a47a-c25668c619aa', 'Green Solutions Ltd.', 'A multinational corporation with a diverse portfolio.', 'Sydney Australia', 'httpswww.techinnovators.com', 'https://i.imgur.com/YfJQV5z.png?id=107');
INSERT INTO "Company" ("id", "name", "description", "location", "website", "logoUrl") VALUES ('b9935e67-baf2-44fe-a3ed-4aa8483bdbe5', 'Green Solutions Ltd.', 'A creative agency dedicated to unique and impactful designs.', 'London UK', 'httpswww.globaldynamics.com', 'https://i.imgur.com/YfJQV5z.png?id=113');
INSERT INTO "Company" ("id", "name", "description", "location", "website", "logoUrl") VALUES ('78b55623-bb3b-41d0-807f-b96030771b61', 'Tech Innovators Inc.', 'A forwardthinking enterprise focused on future technologies.', 'Berlin Germany', 'httpswww.techinnovators.com', 'https://i.imgur.com/YfJQV5z.png?id=119');
INSERT INTO "Company" ("id", "name", "description", "location", "website", "logoUrl") VALUES ('1fbb088b-e7b9-4a36-aea0-f96f030f8ce7', 'Tech Innovators Inc.', 'A creative agency dedicated to unique and impactful designs.', 'Sydney Australia', 'httpswww.greensolutions.com', 'https://i.imgur.com/YfJQV5z.png?id=125');
INSERT INTO "Company" ("id", "name", "description", "location", "website", "logoUrl") VALUES ('f75aa6b8-cea0-4bac-a6aa-cab5546edb92', 'Global Dynamics', 'A multinational corporation with a diverse portfolio.', 'Tokyo Japan', 'httpswww.greensolutions.com', 'https://i.imgur.com/YfJQV5z.png?id=131');
INSERT INTO "Company" ("id", "name", "description", "location", "website", "logoUrl") VALUES ('df5c2a45-2049-4be0-b68e-5cb8d2703f50', 'Creative Minds Co.', 'A multinational corporation with a diverse portfolio.', 'Sydney Australia', 'httpswww.techinnovators.com', 'https://i.imgur.com/YfJQV5z.png?id=137');
INSERT INTO "Company" ("id", "name", "description", "location", "website", "logoUrl") VALUES ('157da230-e891-4c98-b778-a23927ea552b', 'Creative Minds Co.', 'Specializes in ecofriendly products and sustainable solutions.', 'Sydney Australia', 'httpswww.greensolutions.com', 'https://i.imgur.com/YfJQV5z.png?id=143');
INSERT INTO "Company" ("id", "name", "description", "location", "website", "logoUrl") VALUES ('a3d9a818-0f6a-4e05-8347-d30b45371cb5', 'Tech Innovators Inc.', 'A multinational corporation with a diverse portfolio.', 'London UK', 'httpswww.greensolutions.com', 'https://i.imgur.com/YfJQV5z.png?id=149');

INSERT INTO "Student" ("id", "university", "major", "graduationYear", "userId") VALUES ('8958baa2-4d08-447d-b704-963b26654e8f', 'University of California Berkeley', 'Economics', 874, '21a857f1-ba5f-4435-bcf6-f910ec07c0dc');
INSERT INTO "Student" ("id", "university", "major", "graduationYear", "userId") VALUES ('a2b2e1ea-70b5-4144-a258-be464a38f94c', 'University of California Berkeley', 'Biology', 58, 'f008efc6-b911-47ac-836d-a0a045bb9250');
INSERT INTO "Student" ("id", "university", "major", "graduationYear", "userId") VALUES ('628f30db-627c-44f5-9185-9c3b05331bd7', 'Harvard University', 'Psychology', 71, '1798ced1-19cb-41f0-b598-3a796eac9378');
INSERT INTO "Student" ("id", "university", "major", "graduationYear", "userId") VALUES ('f7fae6a5-93c3-49f0-984c-a82deabee231', 'University of Oxford', 'Biology', 445, '1798ced1-19cb-41f0-b598-3a796eac9378');
INSERT INTO "Student" ("id", "university", "major", "graduationYear", "userId") VALUES ('6d801864-f313-4572-bf47-8307cb40926b', 'Stanford University', 'Biology', 328, 'b6ad7d36-2a8e-40b1-ad7e-28a6c085e4a7');
INSERT INTO "Student" ("id", "university", "major", "graduationYear", "userId") VALUES ('6dbe73ec-8c23-4d44-9bdf-8093ef18aac4', 'University of California Berkeley', 'Economics', 689, '21a857f1-ba5f-4435-bcf6-f910ec07c0dc');
INSERT INTO "Student" ("id", "university", "major", "graduationYear", "userId") VALUES ('c68556be-942b-436b-a9cd-7097af9ef4bb', 'University of California Berkeley', 'Psychology', 608, 'eb913330-0213-4a8b-ac8b-8634014a2e56');
INSERT INTO "Student" ("id", "university", "major", "graduationYear", "userId") VALUES ('8c2221b3-6b08-46e5-8fcf-07a08d4db41b', 'University of California Berkeley', 'Psychology', 368, '789a56cb-dcb0-4066-933f-1cc03da14de9');
INSERT INTO "Student" ("id", "university", "major", "graduationYear", "userId") VALUES ('3e6a4e9b-2f7e-4ae7-ac85-37c8eef17897', 'Harvard University', 'Computer Science', 577, '0fb4610a-cbb1-418e-af1a-42a409bbf595');
INSERT INTO "Student" ("id", "university", "major", "graduationYear", "userId") VALUES ('1ec1bb99-6808-4715-87bf-d4f51ebba624', 'Harvard University', 'Economics', 614, 'f008efc6-b911-47ac-836d-a0a045bb9250');

INSERT INTO "Recruiter" ("id", "position", "userId", "companyId") VALUES ('e646354a-4fc2-4f94-9296-8c104aec9c71', 'Recruitment Consultant', 'a64eec48-aed5-4ee7-9bab-7a70fd190f4a', 'b9935e67-baf2-44fe-a3ed-4aa8483bdbe5');
INSERT INTO "Recruiter" ("id", "position", "userId", "companyId") VALUES ('009aa7bc-616d-4910-849e-5bc3cf206944', 'HR Coordinator', '789a56cb-dcb0-4066-933f-1cc03da14de9', 'f75aa6b8-cea0-4bac-a6aa-cab5546edb92');
INSERT INTO "Recruiter" ("id", "position", "userId", "companyId") VALUES ('d0b5d13c-e8cc-4dc4-9697-3d9a73b0edda', 'HR Coordinator', '21a857f1-ba5f-4435-bcf6-f910ec07c0dc', 'f75aa6b8-cea0-4bac-a6aa-cab5546edb92');
INSERT INTO "Recruiter" ("id", "position", "userId", "companyId") VALUES ('7ca9a0b2-8e78-4f2a-8121-cbc0168c3054', 'Campus Recruiter', '0fb4610a-cbb1-418e-af1a-42a409bbf595', '157da230-e891-4c98-b778-a23927ea552b');
INSERT INTO "Recruiter" ("id", "position", "userId", "companyId") VALUES ('65f9d516-070b-4b40-afda-24d690e44f7d', 'Talent Acquisition Specialist', '21a857f1-ba5f-4435-bcf6-f910ec07c0dc', '157da230-e891-4c98-b778-a23927ea552b');
INSERT INTO "Recruiter" ("id", "position", "userId", "companyId") VALUES ('0e94e2d0-f05c-4931-97ba-4ecdc0718af2', 'HR Coordinator', 'f008efc6-b911-47ac-836d-a0a045bb9250', '157da230-e891-4c98-b778-a23927ea552b');
INSERT INTO "Recruiter" ("id", "position", "userId", "companyId") VALUES ('bfb6d639-1116-406f-ab89-4ae8f4c9a577', 'Recruitment Consultant', 'eb913330-0213-4a8b-ac8b-8634014a2e56', 'f75aa6b8-cea0-4bac-a6aa-cab5546edb92');
INSERT INTO "Recruiter" ("id", "position", "userId", "companyId") VALUES ('a6083b2b-a9fe-4e75-b171-c048c44919d4', 'Staffing Manager', 'b6ad7d36-2a8e-40b1-ad7e-28a6c085e4a7', 'f75aa6b8-cea0-4bac-a6aa-cab5546edb92');
INSERT INTO "Recruiter" ("id", "position", "userId", "companyId") VALUES ('bd3dc1f4-a9c1-4c13-a647-0132f46a1b0b', 'Talent Acquisition Specialist', '789a56cb-dcb0-4066-933f-1cc03da14de9', 'a3d9a818-0f6a-4e05-8347-d30b45371cb5');
INSERT INTO "Recruiter" ("id", "position", "userId", "companyId") VALUES ('fb0d2b98-30ec-48c6-85ba-a01d058aa312', 'Campus Recruiter', '0fb4610a-cbb1-418e-af1a-42a409bbf595', '157da230-e891-4c98-b778-a23927ea552b');

INSERT INTO "Job" ("id", "title", "description", "salary", "location", "companyId") VALUES ('81ed7812-b882-4994-a85a-dec68f05a837', 'Software Development Intern', 'Conduct research and compile reports for ongoing projects.', 962, 'San Francisco CA', '157da230-e891-4c98-b778-a23927ea552b');
INSERT INTO "Job" ("id", "title", "description", "salary", "location", "companyId") VALUES ('1431fe4d-9b10-4f43-93b6-09cb049b7af6', 'Marketing Assistant', 'Support the marketing team in campaign planning and execution.', 277, 'Boston MA', 'a3d9a818-0f6a-4e05-8347-d30b45371cb5');
INSERT INTO "Job" ("id", "title", "description", "salary", "location", "companyId") VALUES ('8019b94d-2c86-49f3-9140-76f337ff7507', 'Data Analyst Trainee', 'Conduct research and compile reports for ongoing projects.', 644, 'Seattle WA', '6cab533e-868c-4d33-8bee-192e6fb95068');
INSERT INTO "Job" ("id", "title", "description", "salary", "location", "companyId") VALUES ('71826d8a-356b-4d60-b2d5-9e96adc5cb2c', 'Graphic Design Intern', 'Conduct research and compile reports for ongoing projects.', 744, 'Boston MA', '1fbb088b-e7b9-4a36-aea0-f96f030f8ce7');
INSERT INTO "Job" ("id", "title", "description", "salary", "location", "companyId") VALUES ('2b432b28-7014-45f8-bfe9-9e790b9a5c62', 'Software Development Intern', 'Create visual content for digital and print media.', 667, 'San Francisco CA', '1fbb088b-e7b9-4a36-aea0-f96f030f8ce7');
INSERT INTO "Job" ("id", "title", "description", "salary", "location", "companyId") VALUES ('814a5150-6247-4c6c-bca0-d391130c94fa', 'Graphic Design Intern', 'Analyze data sets to provide insights and recommendations.', 906, 'Boston MA', 'f75aa6b8-cea0-4bac-a6aa-cab5546edb92');
INSERT INTO "Job" ("id", "title", "description", "salary", "location", "companyId") VALUES ('71947e5f-a4c6-4626-9b5a-a99f70dc6727', 'Data Analyst Trainee', 'Create visual content for digital and print media.', 739, 'New York NY', 'b311558f-1a62-4b2d-8801-686ae990a01c');
INSERT INTO "Job" ("id", "title", "description", "salary", "location", "companyId") VALUES ('530a4da8-fb81-42c8-82a9-9f6a527c240e', 'Graphic Design Intern', 'Assist in developing and testing software applications.', 136, 'Seattle WA', 'a3d9a818-0f6a-4e05-8347-d30b45371cb5');
INSERT INTO "Job" ("id", "title", "description", "salary", "location", "companyId") VALUES ('503f6f63-15d0-41f5-8287-5ab1d865b45c', 'Research Assistant', 'Conduct research and compile reports for ongoing projects.', 872, 'Seattle WA', 'df5c2a45-2049-4be0-b68e-5cb8d2703f50');
INSERT INTO "Job" ("id", "title", "description", "salary", "location", "companyId") VALUES ('0dacf760-2e02-4cdb-951f-d011632bfa9a', 'Graphic Design Intern', 'Assist in developing and testing software applications.', 190, 'Seattle WA', 'b9935e67-baf2-44fe-a3ed-4aa8483bdbe5');

INSERT INTO "Application" ("id", "status", "applicationDate", "jobId", "studentId") VALUES ('2b431049-5dd6-45f8-bea6-2aa827a2acb1', 'Under Review', '2025-06-25T21:48:37.488Z', '530a4da8-fb81-42c8-82a9-9f6a527c240e', '8958baa2-4d08-447d-b704-963b26654e8f');
INSERT INTO "Application" ("id", "status", "applicationDate", "jobId", "studentId") VALUES ('6c4b9d06-f15b-45c8-a272-af37e42bf786', 'Rejected', '2025-09-16T14:09:18.969Z', '81ed7812-b882-4994-a85a-dec68f05a837', '628f30db-627c-44f5-9185-9c3b05331bd7');
INSERT INTO "Application" ("id", "status", "applicationDate", "jobId", "studentId") VALUES ('6b8375e6-db6d-44bc-b8e6-efa7be99fc6f', 'Under Review', '2024-03-15T10:05:37.154Z', '0dacf760-2e02-4cdb-951f-d011632bfa9a', '628f30db-627c-44f5-9185-9c3b05331bd7');
INSERT INTO "Application" ("id", "status", "applicationDate", "jobId", "studentId") VALUES ('4a4a4cc6-b235-449c-9a23-d207f926bef8', 'Interview Scheduled', '2025-01-07T11:12:17.338Z', '814a5150-6247-4c6c-bca0-d391130c94fa', '6d801864-f313-4572-bf47-8307cb40926b');
INSERT INTO "Application" ("id", "status", "applicationDate", "jobId", "studentId") VALUES ('6ee4f954-0f69-411f-89fa-31378ae70aaa', 'Rejected', '2024-05-13T07:37:21.500Z', '2b432b28-7014-45f8-bfe9-9e790b9a5c62', '628f30db-627c-44f5-9185-9c3b05331bd7');
INSERT INTO "Application" ("id", "status", "applicationDate", "jobId", "studentId") VALUES ('3b0787cf-c4bd-4492-9cff-4974b6db6ef8', 'Pending', '2025-03-05T14:03:53.834Z', '530a4da8-fb81-42c8-82a9-9f6a527c240e', '6dbe73ec-8c23-4d44-9bdf-8093ef18aac4');
INSERT INTO "Application" ("id", "status", "applicationDate", "jobId", "studentId") VALUES ('36729460-6a67-4753-829d-87108ad0dff7', 'Pending', '2024-02-04T12:42:59.328Z', '530a4da8-fb81-42c8-82a9-9f6a527c240e', '1ec1bb99-6808-4715-87bf-d4f51ebba624');
INSERT INTO "Application" ("id", "status", "applicationDate", "jobId", "studentId") VALUES ('193a0909-d703-4078-928f-f551ff3022e8', 'Approved', '2024-08-25T13:31:58.663Z', '503f6f63-15d0-41f5-8287-5ab1d865b45c', 'c68556be-942b-436b-a9cd-7097af9ef4bb');
INSERT INTO "Application" ("id", "status", "applicationDate", "jobId", "studentId") VALUES ('00694545-2f2d-4d51-a766-1cbc7d36add6', 'Approved', '2024-03-08T21:41:52.765Z', '814a5150-6247-4c6c-bca0-d391130c94fa', '8c2221b3-6b08-46e5-8fcf-07a08d4db41b');
INSERT INTO "Application" ("id", "status", "applicationDate", "jobId", "studentId") VALUES ('ed65394c-901d-4e7d-a968-cceff53932a8', 'Pending', '2025-03-20T16:14:50.203Z', '2b432b28-7014-45f8-bfe9-9e790b9a5c62', 'f7fae6a5-93c3-49f0-984c-a82deabee231');

INSERT INTO "Interview" ("id", "dateTime", "location", "status", "applicationId", "recruiterId") VALUES ('d2bc02d0-d3ef-49b1-a749-bbe0a41f1e60', '2024-08-01T05:55:05.502Z', 'Online  Zoom', 'Completed', '4a4a4cc6-b235-449c-9a23-d207f926bef8', 'd0b5d13c-e8cc-4dc4-9697-3d9a73b0edda');
INSERT INTO "Interview" ("id", "dateTime", "location", "status", "applicationId", "recruiterId") VALUES ('b7ba5681-f123-4e1a-8fa7-a7897ffdf3c0', '2024-08-08T04:54:05.405Z', 'Online  Zoom', 'Rescheduled', '3b0787cf-c4bd-4492-9cff-4974b6db6ef8', 'bfb6d639-1116-406f-ab89-4ae8f4c9a577');
INSERT INTO "Interview" ("id", "dateTime", "location", "status", "applicationId", "recruiterId") VALUES ('e277ceef-5303-46ac-9e3e-6e244f38834a', '2024-11-10T11:58:20.793Z', 'Main Campus Auditorium', 'Rescheduled', '36729460-6a67-4753-829d-87108ad0dff7', 'fb0d2b98-30ec-48c6-85ba-a01d058aa312');
INSERT INTO "Interview" ("id", "dateTime", "location", "status", "applicationId", "recruiterId") VALUES ('ac0aec7d-502b-4174-b649-39315e9a0bda', '2025-08-05T06:05:05.883Z', 'Building B Room 3', 'Scheduled', '2b431049-5dd6-45f8-bea6-2aa827a2acb1', '0e94e2d0-f05c-4931-97ba-4ecdc0718af2');
INSERT INTO "Interview" ("id", "dateTime", "location", "status", "applicationId", "recruiterId") VALUES ('7b507364-a537-45df-8c7b-292679419295', '2025-07-19T14:11:42.822Z', 'Conference Hall A', 'Pending', '4a4a4cc6-b235-449c-9a23-d207f926bef8', '7ca9a0b2-8e78-4f2a-8121-cbc0168c3054');
INSERT INTO "Interview" ("id", "dateTime", "location", "status", "applicationId", "recruiterId") VALUES ('fc545cf8-46f2-4f44-aa86-e669125547d6', '2023-12-31T16:51:59.159Z', 'Conference Hall A', 'Cancelled', '00694545-2f2d-4d51-a766-1cbc7d36add6', 'fb0d2b98-30ec-48c6-85ba-a01d058aa312');
INSERT INTO "Interview" ("id", "dateTime", "location", "status", "applicationId", "recruiterId") VALUES ('bb1a5d55-1c99-4dc4-9872-d1fcc20f28a7', '2024-09-11T04:32:59.792Z', 'Building B Room 3', 'Rescheduled', '193a0909-d703-4078-928f-f551ff3022e8', 'bfb6d639-1116-406f-ab89-4ae8f4c9a577');
INSERT INTO "Interview" ("id", "dateTime", "location", "status", "applicationId", "recruiterId") VALUES ('75b62d85-27c5-48c7-ac2a-be0ce6c28e46', '2024-12-08T10:17:01.569Z', 'Conference Hall A', 'Cancelled', '193a0909-d703-4078-928f-f551ff3022e8', 'a6083b2b-a9fe-4e75-b171-c048c44919d4');
INSERT INTO "Interview" ("id", "dateTime", "location", "status", "applicationId", "recruiterId") VALUES ('be3a6f0b-1671-42d9-8b0b-f774177ba79a', '2025-05-16T14:50:45.832Z', 'Online  Zoom', 'Rescheduled', '36729460-6a67-4753-829d-87108ad0dff7', 'a6083b2b-a9fe-4e75-b171-c048c44919d4');
INSERT INTO "Interview" ("id", "dateTime", "location", "status", "applicationId", "recruiterId") VALUES ('1f7e3b29-ee2a-4b35-9af8-304c44ed9814', '2023-11-22T13:30:43.137Z', 'Conference Hall A', 'Scheduled', '6b8375e6-db6d-44bc-b8e6-efa7be99fc6f', 'bd3dc1f4-a9c1-4c13-a647-0132f46a1b0b');

  `

  const sqls = splitSql(sql)

  for (const sql of sqls) {
    try {
      await prisma.$executeRawUnsafe(`${sql}`)
    } catch (error) {
      console.log(`Could not insert SQL: ${error.message}`)
    }
  }
}

main()
  .then(async () => {
    await prisma.$disconnect()
  })
  .catch(async error => {
    console.error(error)
    await prisma.$disconnect()
    process.exit(1)
  })
