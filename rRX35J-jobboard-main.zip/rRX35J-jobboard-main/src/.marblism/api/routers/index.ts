/* eslint-disable */
import type { unsetMarker, AnyRouter, AnyRootConfig, CreateRouterInner, Procedure, ProcedureBuilder, ProcedureParams, ProcedureRouterRecord, ProcedureType } from "@trpc/server";
import type { PrismaClient } from "@prisma/client";
import createCompanyRouter from "./Company.router";
import createStudentRouter from "./Student.router";
import createRecruiterRouter from "./Recruiter.router";
import createJobRouter from "./Job.router";
import createApplicationRouter from "./Application.router";
import createInterviewRouter from "./Interview.router";
import createUserRouter from "./User.router";
import createAccountRouter from "./Account.router";
import createSessionRouter from "./Session.router";
import { ClientType as CompanyClientType } from "./Company.router";
import { ClientType as StudentClientType } from "./Student.router";
import { ClientType as RecruiterClientType } from "./Recruiter.router";
import { ClientType as JobClientType } from "./Job.router";
import { ClientType as ApplicationClientType } from "./Application.router";
import { ClientType as InterviewClientType } from "./Interview.router";
import { ClientType as UserClientType } from "./User.router";
import { ClientType as AccountClientType } from "./Account.router";
import { ClientType as SessionClientType } from "./Session.router";

export type BaseConfig = AnyRootConfig;

export type RouterFactory<Config extends BaseConfig> = <
    ProcRouterRecord extends ProcedureRouterRecord
>(
    procedures: ProcRouterRecord
) => CreateRouterInner<Config, ProcRouterRecord>;

export type UnsetMarker = typeof unsetMarker;

export type ProcBuilder<Config extends BaseConfig> = ProcedureBuilder<
    ProcedureParams<Config, any, any, any, UnsetMarker, UnsetMarker, any>
>;

export function db(ctx: any) {
    if (!ctx.prisma) {
        throw new Error('Missing "prisma" field in trpc context');
    }
    return ctx.prisma as PrismaClient;
}

export function createRouter<Config extends BaseConfig>(router: RouterFactory<Config>, procedure: ProcBuilder<Config>) {
    return router({
        company: createCompanyRouter(router, procedure),
        student: createStudentRouter(router, procedure),
        recruiter: createRecruiterRouter(router, procedure),
        job: createJobRouter(router, procedure),
        application: createApplicationRouter(router, procedure),
        interview: createInterviewRouter(router, procedure),
        user: createUserRouter(router, procedure),
        account: createAccountRouter(router, procedure),
        session: createSessionRouter(router, procedure),
    }
    );
}

export interface ClientType<AppRouter extends AnyRouter> {
    company: CompanyClientType<AppRouter>;
    student: StudentClientType<AppRouter>;
    recruiter: RecruiterClientType<AppRouter>;
    job: JobClientType<AppRouter>;
    application: ApplicationClientType<AppRouter>;
    interview: InterviewClientType<AppRouter>;
    user: UserClientType<AppRouter>;
    account: AccountClientType<AppRouter>;
    session: SessionClientType<AppRouter>;
}
