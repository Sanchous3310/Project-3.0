/* eslint-disable */
import { type RouterFactory, type ProcBuilder, type BaseConfig, db } from ".";
import * as _Schema from '@zenstackhq/runtime/zod/input';
const $Schema: typeof _Schema = (_Schema as any).default ?? _Schema;
import { checkRead, checkMutate } from '../helper';
import type { Prisma } from '@prisma/client';
import type { UseTRPCMutationOptions, UseTRPCMutationResult, UseTRPCQueryOptions, UseTRPCQueryResult, UseTRPCInfiniteQueryOptions, UseTRPCInfiniteQueryResult } from '@trpc/react-query/shared';
import type { TRPCClientErrorLike } from '@trpc/client';
import type { AnyRouter } from '@trpc/server';

export default function createRouter<Config extends BaseConfig>(router: RouterFactory<Config>, procedure: ProcBuilder<Config>) {
    return router({

        createMany: procedure.input($Schema.InterviewInputSchema.createMany).mutation(async ({ ctx, input }) => checkMutate(db(ctx).interview.createMany(input as any))),

        create: procedure.input($Schema.InterviewInputSchema.create).mutation(async ({ ctx, input }) => checkMutate(db(ctx).interview.create(input as any))),

        deleteMany: procedure.input($Schema.InterviewInputSchema.deleteMany).mutation(async ({ ctx, input }) => checkMutate(db(ctx).interview.deleteMany(input as any))),

        delete: procedure.input($Schema.InterviewInputSchema.delete).mutation(async ({ ctx, input }) => checkMutate(db(ctx).interview.delete(input as any))),

        findFirst: procedure.input($Schema.InterviewInputSchema.findFirst).query(({ ctx, input }) => checkRead(db(ctx).interview.findFirst(input as any))),

        findMany: procedure.input($Schema.InterviewInputSchema.findMany).query(({ ctx, input }) => checkRead(db(ctx).interview.findMany(input as any))),

        findUnique: procedure.input($Schema.InterviewInputSchema.findUnique).query(({ ctx, input }) => checkRead(db(ctx).interview.findUnique(input as any))),

        updateMany: procedure.input($Schema.InterviewInputSchema.updateMany).mutation(async ({ ctx, input }) => checkMutate(db(ctx).interview.updateMany(input as any))),

        update: procedure.input($Schema.InterviewInputSchema.update).mutation(async ({ ctx, input }) => checkMutate(db(ctx).interview.update(input as any))),

    }
    );
}

export interface ClientType<AppRouter extends AnyRouter, Context = AppRouter['_def']['_config']['$types']['ctx']> {
    createMany: {

        useMutation: <T extends Prisma.InterviewCreateManyArgs>(opts?: UseTRPCMutationOptions<
            Prisma.InterviewCreateManyArgs,
            TRPCClientErrorLike<AppRouter>,
            Prisma.BatchPayload,
            Context
        >,) =>
            Omit<UseTRPCMutationResult<Prisma.BatchPayload, TRPCClientErrorLike<AppRouter>, Prisma.SelectSubset<T, Prisma.InterviewCreateManyArgs>, Context>, 'mutateAsync'> & {
                mutateAsync:
                <T extends Prisma.InterviewCreateManyArgs>(variables: T, opts?: UseTRPCMutationOptions<T, TRPCClientErrorLike<AppRouter>, Prisma.BatchPayload, Context>) => Promise<Prisma.BatchPayload>
            };

    };
    create: {

        useMutation: <T extends Prisma.InterviewCreateArgs>(opts?: UseTRPCMutationOptions<
            Prisma.InterviewCreateArgs,
            TRPCClientErrorLike<AppRouter>,
            Prisma.InterviewGetPayload<T>,
            Context
        >,) =>
            Omit<UseTRPCMutationResult<Prisma.InterviewGetPayload<T>, TRPCClientErrorLike<AppRouter>, Prisma.SelectSubset<T, Prisma.InterviewCreateArgs>, Context>, 'mutateAsync'> & {
                mutateAsync:
                <T extends Prisma.InterviewCreateArgs>(variables: T, opts?: UseTRPCMutationOptions<T, TRPCClientErrorLike<AppRouter>, Prisma.InterviewGetPayload<T>, Context>) => Promise<Prisma.InterviewGetPayload<T>>
            };

    };
    deleteMany: {

        useMutation: <T extends Prisma.InterviewDeleteManyArgs>(opts?: UseTRPCMutationOptions<
            Prisma.InterviewDeleteManyArgs,
            TRPCClientErrorLike<AppRouter>,
            Prisma.BatchPayload,
            Context
        >,) =>
            Omit<UseTRPCMutationResult<Prisma.BatchPayload, TRPCClientErrorLike<AppRouter>, Prisma.SelectSubset<T, Prisma.InterviewDeleteManyArgs>, Context>, 'mutateAsync'> & {
                mutateAsync:
                <T extends Prisma.InterviewDeleteManyArgs>(variables: T, opts?: UseTRPCMutationOptions<T, TRPCClientErrorLike<AppRouter>, Prisma.BatchPayload, Context>) => Promise<Prisma.BatchPayload>
            };

    };
    delete: {

        useMutation: <T extends Prisma.InterviewDeleteArgs>(opts?: UseTRPCMutationOptions<
            Prisma.InterviewDeleteArgs,
            TRPCClientErrorLike<AppRouter>,
            Prisma.InterviewGetPayload<T>,
            Context
        >,) =>
            Omit<UseTRPCMutationResult<Prisma.InterviewGetPayload<T>, TRPCClientErrorLike<AppRouter>, Prisma.SelectSubset<T, Prisma.InterviewDeleteArgs>, Context>, 'mutateAsync'> & {
                mutateAsync:
                <T extends Prisma.InterviewDeleteArgs>(variables: T, opts?: UseTRPCMutationOptions<T, TRPCClientErrorLike<AppRouter>, Prisma.InterviewGetPayload<T>, Context>) => Promise<Prisma.InterviewGetPayload<T>>
            };

    };
    findFirst: {

        useQuery: <T extends Prisma.InterviewFindFirstArgs, TData = Prisma.InterviewGetPayload<T>>(
            input: Prisma.SelectSubset<T, Prisma.InterviewFindFirstArgs>,
            opts?: UseTRPCQueryOptions<string, T, Prisma.InterviewGetPayload<T>, TData, Error>
        ) => UseTRPCQueryResult<
            TData,
            TRPCClientErrorLike<AppRouter>
        >;
        useInfiniteQuery: <T extends Prisma.InterviewFindFirstArgs>(
            input: Omit<Prisma.SelectSubset<T, Prisma.InterviewFindFirstArgs>, 'cursor'>,
            opts?: UseTRPCInfiniteQueryOptions<string, T, Prisma.InterviewGetPayload<T>, Error>
        ) => UseTRPCInfiniteQueryResult<
            Prisma.InterviewGetPayload<T>,
            TRPCClientErrorLike<AppRouter>
        >;

    };
    findMany: {

        useQuery: <T extends Prisma.InterviewFindManyArgs, TData = Array<Prisma.InterviewGetPayload<T>>>(
            input: Prisma.SelectSubset<T, Prisma.InterviewFindManyArgs>,
            opts?: UseTRPCQueryOptions<string, T, Array<Prisma.InterviewGetPayload<T>>, TData, Error>
        ) => UseTRPCQueryResult<
            TData,
            TRPCClientErrorLike<AppRouter>
        >;
        useInfiniteQuery: <T extends Prisma.InterviewFindManyArgs>(
            input: Omit<Prisma.SelectSubset<T, Prisma.InterviewFindManyArgs>, 'cursor'>,
            opts?: UseTRPCInfiniteQueryOptions<string, T, Array<Prisma.InterviewGetPayload<T>>, Error>
        ) => UseTRPCInfiniteQueryResult<
            Array<Prisma.InterviewGetPayload<T>>,
            TRPCClientErrorLike<AppRouter>
        >;

    };
    findUnique: {

        useQuery: <T extends Prisma.InterviewFindUniqueArgs, TData = Prisma.InterviewGetPayload<T>>(
            input: Prisma.SelectSubset<T, Prisma.InterviewFindUniqueArgs>,
            opts?: UseTRPCQueryOptions<string, T, Prisma.InterviewGetPayload<T>, TData, Error>
        ) => UseTRPCQueryResult<
            TData,
            TRPCClientErrorLike<AppRouter>
        >;
        useInfiniteQuery: <T extends Prisma.InterviewFindUniqueArgs>(
            input: Omit<Prisma.SelectSubset<T, Prisma.InterviewFindUniqueArgs>, 'cursor'>,
            opts?: UseTRPCInfiniteQueryOptions<string, T, Prisma.InterviewGetPayload<T>, Error>
        ) => UseTRPCInfiniteQueryResult<
            Prisma.InterviewGetPayload<T>,
            TRPCClientErrorLike<AppRouter>
        >;

    };
    updateMany: {

        useMutation: <T extends Prisma.InterviewUpdateManyArgs>(opts?: UseTRPCMutationOptions<
            Prisma.InterviewUpdateManyArgs,
            TRPCClientErrorLike<AppRouter>,
            Prisma.BatchPayload,
            Context
        >,) =>
            Omit<UseTRPCMutationResult<Prisma.BatchPayload, TRPCClientErrorLike<AppRouter>, Prisma.SelectSubset<T, Prisma.InterviewUpdateManyArgs>, Context>, 'mutateAsync'> & {
                mutateAsync:
                <T extends Prisma.InterviewUpdateManyArgs>(variables: T, opts?: UseTRPCMutationOptions<T, TRPCClientErrorLike<AppRouter>, Prisma.BatchPayload, Context>) => Promise<Prisma.BatchPayload>
            };

    };
    update: {

        useMutation: <T extends Prisma.InterviewUpdateArgs>(opts?: UseTRPCMutationOptions<
            Prisma.InterviewUpdateArgs,
            TRPCClientErrorLike<AppRouter>,
            Prisma.InterviewGetPayload<T>,
            Context
        >,) =>
            Omit<UseTRPCMutationResult<Prisma.InterviewGetPayload<T>, TRPCClientErrorLike<AppRouter>, Prisma.SelectSubset<T, Prisma.InterviewUpdateArgs>, Context>, 'mutateAsync'> & {
                mutateAsync:
                <T extends Prisma.InterviewUpdateArgs>(variables: T, opts?: UseTRPCMutationOptions<T, TRPCClientErrorLike<AppRouter>, Prisma.InterviewGetPayload<T>, Context>) => Promise<Prisma.InterviewGetPayload<T>>
            };

    };
}
