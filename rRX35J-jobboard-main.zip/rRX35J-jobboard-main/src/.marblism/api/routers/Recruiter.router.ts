/* eslint-disable */
import { type RouterFactory, type ProcBuilder, type BaseConfig, db } from ".";
import * as _Schema from '@zenstackhq/runtime/zod/input';
const $Schema: typeof _Schema = (_Schema as any).default ?? _Schema;
import { checkRead, checkMutate } from '../helper';
import type { Prisma } from '@prisma/client';
import type { UseTRPCMutationOptions, UseTRPCMutationResult, UseTRPCQueryOptions, UseTRPCQueryResult, UseTRPCInfiniteQueryOptions, UseTRPCInfiniteQueryResult } from '@trpc/react-query/shared';
import type { TRPCClientErrorLike } from '@trpc/client';
import type { AnyRouter } from '@trpc/server';

export default function createRouter<Config extends BaseConfig>(router: RouterFactory<Config>, procedure: ProcBuilder<Config>) {
    return router({

        createMany: procedure.input($Schema.RecruiterInputSchema.createMany).mutation(async ({ ctx, input }) => checkMutate(db(ctx).recruiter.createMany(input as any))),

        create: procedure.input($Schema.RecruiterInputSchema.create).mutation(async ({ ctx, input }) => checkMutate(db(ctx).recruiter.create(input as any))),

        deleteMany: procedure.input($Schema.RecruiterInputSchema.deleteMany).mutation(async ({ ctx, input }) => checkMutate(db(ctx).recruiter.deleteMany(input as any))),

        delete: procedure.input($Schema.RecruiterInputSchema.delete).mutation(async ({ ctx, input }) => checkMutate(db(ctx).recruiter.delete(input as any))),

        findFirst: procedure.input($Schema.RecruiterInputSchema.findFirst).query(({ ctx, input }) => checkRead(db(ctx).recruiter.findFirst(input as any))),

        findMany: procedure.input($Schema.RecruiterInputSchema.findMany).query(({ ctx, input }) => checkRead(db(ctx).recruiter.findMany(input as any))),

        findUnique: procedure.input($Schema.RecruiterInputSchema.findUnique).query(({ ctx, input }) => checkRead(db(ctx).recruiter.findUnique(input as any))),

        updateMany: procedure.input($Schema.RecruiterInputSchema.updateMany).mutation(async ({ ctx, input }) => checkMutate(db(ctx).recruiter.updateMany(input as any))),

        update: procedure.input($Schema.RecruiterInputSchema.update).mutation(async ({ ctx, input }) => checkMutate(db(ctx).recruiter.update(input as any))),

    }
    );
}

export interface ClientType<AppRouter extends AnyRouter, Context = AppRouter['_def']['_config']['$types']['ctx']> {
    createMany: {

        useMutation: <T extends Prisma.RecruiterCreateManyArgs>(opts?: UseTRPCMutationOptions<
            Prisma.RecruiterCreateManyArgs,
            TRPCClientErrorLike<AppRouter>,
            Prisma.BatchPayload,
            Context
        >,) =>
            Omit<UseTRPCMutationResult<Prisma.BatchPayload, TRPCClientErrorLike<AppRouter>, Prisma.SelectSubset<T, Prisma.RecruiterCreateManyArgs>, Context>, 'mutateAsync'> & {
                mutateAsync:
                <T extends Prisma.RecruiterCreateManyArgs>(variables: T, opts?: UseTRPCMutationOptions<T, TRPCClientErrorLike<AppRouter>, Prisma.BatchPayload, Context>) => Promise<Prisma.BatchPayload>
            };

    };
    create: {

        useMutation: <T extends Prisma.RecruiterCreateArgs>(opts?: UseTRPCMutationOptions<
            Prisma.RecruiterCreateArgs,
            TRPCClientErrorLike<AppRouter>,
            Prisma.RecruiterGetPayload<T>,
            Context
        >,) =>
            Omit<UseTRPCMutationResult<Prisma.RecruiterGetPayload<T>, TRPCClientErrorLike<AppRouter>, Prisma.SelectSubset<T, Prisma.RecruiterCreateArgs>, Context>, 'mutateAsync'> & {
                mutateAsync:
                <T extends Prisma.RecruiterCreateArgs>(variables: T, opts?: UseTRPCMutationOptions<T, TRPCClientErrorLike<AppRouter>, Prisma.RecruiterGetPayload<T>, Context>) => Promise<Prisma.RecruiterGetPayload<T>>
            };

    };
    deleteMany: {

        useMutation: <T extends Prisma.RecruiterDeleteManyArgs>(opts?: UseTRPCMutationOptions<
            Prisma.RecruiterDeleteManyArgs,
            TRPCClientErrorLike<AppRouter>,
            Prisma.BatchPayload,
            Context
        >,) =>
            Omit<UseTRPCMutationResult<Prisma.BatchPayload, TRPCClientErrorLike<AppRouter>, Prisma.SelectSubset<T, Prisma.RecruiterDeleteManyArgs>, Context>, 'mutateAsync'> & {
                mutateAsync:
                <T extends Prisma.RecruiterDeleteManyArgs>(variables: T, opts?: UseTRPCMutationOptions<T, TRPCClientErrorLike<AppRouter>, Prisma.BatchPayload, Context>) => Promise<Prisma.BatchPayload>
            };

    };
    delete: {

        useMutation: <T extends Prisma.RecruiterDeleteArgs>(opts?: UseTRPCMutationOptions<
            Prisma.RecruiterDeleteArgs,
            TRPCClientErrorLike<AppRouter>,
            Prisma.RecruiterGetPayload<T>,
            Context
        >,) =>
            Omit<UseTRPCMutationResult<Prisma.RecruiterGetPayload<T>, TRPCClientErrorLike<AppRouter>, Prisma.SelectSubset<T, Prisma.RecruiterDeleteArgs>, Context>, 'mutateAsync'> & {
                mutateAsync:
                <T extends Prisma.RecruiterDeleteArgs>(variables: T, opts?: UseTRPCMutationOptions<T, TRPCClientErrorLike<AppRouter>, Prisma.RecruiterGetPayload<T>, Context>) => Promise<Prisma.RecruiterGetPayload<T>>
            };

    };
    findFirst: {

        useQuery: <T extends Prisma.RecruiterFindFirstArgs, TData = Prisma.RecruiterGetPayload<T>>(
            input: Prisma.SelectSubset<T, Prisma.RecruiterFindFirstArgs>,
            opts?: UseTRPCQueryOptions<string, T, Prisma.RecruiterGetPayload<T>, TData, Error>
        ) => UseTRPCQueryResult<
            TData,
            TRPCClientErrorLike<AppRouter>
        >;
        useInfiniteQuery: <T extends Prisma.RecruiterFindFirstArgs>(
            input: Omit<Prisma.SelectSubset<T, Prisma.RecruiterFindFirstArgs>, 'cursor'>,
            opts?: UseTRPCInfiniteQueryOptions<string, T, Prisma.RecruiterGetPayload<T>, Error>
        ) => UseTRPCInfiniteQueryResult<
            Prisma.RecruiterGetPayload<T>,
            TRPCClientErrorLike<AppRouter>
        >;

    };
    findMany: {

        useQuery: <T extends Prisma.RecruiterFindManyArgs, TData = Array<Prisma.RecruiterGetPayload<T>>>(
            input: Prisma.SelectSubset<T, Prisma.RecruiterFindManyArgs>,
            opts?: UseTRPCQueryOptions<string, T, Array<Prisma.RecruiterGetPayload<T>>, TData, Error>
        ) => UseTRPCQueryResult<
            TData,
            TRPCClientErrorLike<AppRouter>
        >;
        useInfiniteQuery: <T extends Prisma.RecruiterFindManyArgs>(
            input: Omit<Prisma.SelectSubset<T, Prisma.RecruiterFindManyArgs>, 'cursor'>,
            opts?: UseTRPCInfiniteQueryOptions<string, T, Array<Prisma.RecruiterGetPayload<T>>, Error>
        ) => UseTRPCInfiniteQueryResult<
            Array<Prisma.RecruiterGetPayload<T>>,
            TRPCClientErrorLike<AppRouter>
        >;

    };
    findUnique: {

        useQuery: <T extends Prisma.RecruiterFindUniqueArgs, TData = Prisma.RecruiterGetPayload<T>>(
            input: Prisma.SelectSubset<T, Prisma.RecruiterFindUniqueArgs>,
            opts?: UseTRPCQueryOptions<string, T, Prisma.RecruiterGetPayload<T>, TData, Error>
        ) => UseTRPCQueryResult<
            TData,
            TRPCClientErrorLike<AppRouter>
        >;
        useInfiniteQuery: <T extends Prisma.RecruiterFindUniqueArgs>(
            input: Omit<Prisma.SelectSubset<T, Prisma.RecruiterFindUniqueArgs>, 'cursor'>,
            opts?: UseTRPCInfiniteQueryOptions<string, T, Prisma.RecruiterGetPayload<T>, Error>
        ) => UseTRPCInfiniteQueryResult<
            Prisma.RecruiterGetPayload<T>,
            TRPCClientErrorLike<AppRouter>
        >;

    };
    updateMany: {

        useMutation: <T extends Prisma.RecruiterUpdateManyArgs>(opts?: UseTRPCMutationOptions<
            Prisma.RecruiterUpdateManyArgs,
            TRPCClientErrorLike<AppRouter>,
            Prisma.BatchPayload,
            Context
        >,) =>
            Omit<UseTRPCMutationResult<Prisma.BatchPayload, TRPCClientErrorLike<AppRouter>, Prisma.SelectSubset<T, Prisma.RecruiterUpdateManyArgs>, Context>, 'mutateAsync'> & {
                mutateAsync:
                <T extends Prisma.RecruiterUpdateManyArgs>(variables: T, opts?: UseTRPCMutationOptions<T, TRPCClientErrorLike<AppRouter>, Prisma.BatchPayload, Context>) => Promise<Prisma.BatchPayload>
            };

    };
    update: {

        useMutation: <T extends Prisma.RecruiterUpdateArgs>(opts?: UseTRPCMutationOptions<
            Prisma.RecruiterUpdateArgs,
            TRPCClientErrorLike<AppRouter>,
            Prisma.RecruiterGetPayload<T>,
            Context
        >,) =>
            Omit<UseTRPCMutationResult<Prisma.RecruiterGetPayload<T>, TRPCClientErrorLike<AppRouter>, Prisma.SelectSubset<T, Prisma.RecruiterUpdateArgs>, Context>, 'mutateAsync'> & {
                mutateAsync:
                <T extends Prisma.RecruiterUpdateArgs>(variables: T, opts?: UseTRPCMutationOptions<T, TRPCClientErrorLike<AppRouter>, Prisma.RecruiterGetPayload<T>, Context>) => Promise<Prisma.RecruiterGetPayload<T>>
            };

    };
}
