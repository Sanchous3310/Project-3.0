export const TemplateWelcome = `
<Card.Header>
  <h2>Welcome to jobboard</h2>
  <hr />
</Card.Header>

<Card.Body>
  <p>Your account is now active.</p>
</Card.Body>

<Card.Footer>
  <p>Sent by jobboard</p>
</Card.Footer>
  `.trim()
