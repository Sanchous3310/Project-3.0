'use client'

import { useState } from 'react'
import {
  Typography,
  Input,
  Button,
  Card,
  Row,
  Col,
  Form,
  Space,
  InputNumber,
} from 'antd'
import { SearchOutlined, PlusOutlined } from '@ant-design/icons'
const { Title, Text } = Typography
import { useUserContext } from '@/core/context'
import { useRouter, useParams } from 'next/navigation'
import { useUploadPublic } from '@/core/hooks/upload'
import { useSnackbar } from 'notistack'
import dayjs from 'dayjs'
import { Api } from '@/core/trpc'
import { PageLayout } from '@/designSystem'

export default function JobListingsPage() {
  const router = useRouter()
  const params = useParams<any>()
  const { user } = useUserContext()
  const { enqueueSnackbar } = useSnackbar()

  const [searchTerm, setSearchTerm] = useState('')
  const [newJob, setNewJob] = useState({
    title: '',
    description: '',
    salary: 0,
    location: '',
  })

  const { data: jobs, refetch } = Api.job.findMany.useQuery({
    include: { company: true },
    where: {
      OR: [
        { title: { contains: searchTerm, mode: 'insensitive' } },
        { description: { contains: searchTerm, mode: 'insensitive' } },
      ],
    },
  })

  const { mutateAsync: createJob } = Api.job.create.useMutation()

  const handleSearch = (value: string) => {
    setSearchTerm(value)
  }

  const handleCreateJob = async () => {
    try {
      await createJob({
        data: {
          ...newJob,
        },
      })
      enqueueSnackbar('Job created successfully', { variant: 'success' })
      refetch()
      setNewJob({ title: '', description: '', salary: 0, location: '' })
    } catch (error) {
      enqueueSnackbar('Failed to create job', { variant: 'error' })
    }
  }

  const isRecruiter = user?.globalRole === 'RECRUITER'

  return (
    <PageLayout layout="narrow">
      <Title level={2}>Job Listings</Title>
      <Text>
        Browse and search for job listings that match your skills and interests.
      </Text>

      <Space
        direction="vertical"
        size="large"
        style={{ width: '100%', marginTop: '20px' }}
      >
        <Input
          placeholder="Search jobs"
          prefix={<SearchOutlined />}
          onChange={e => handleSearch(e.target.value)}
        />

        {isRecruiter && (
          <Card title="Post a New Job">
            <Form layout="vertical">
              <Form.Item label="Title">
                <Input
                  value={newJob.title}
                  onChange={e =>
                    setNewJob({ ...newJob, title: e.target.value })
                  }
                />
              </Form.Item>
              <Form.Item label="Description">
                <Input.TextArea
                  value={newJob.description}
                  onChange={e =>
                    setNewJob({ ...newJob, description: e.target.value })
                  }
                />
              </Form.Item>
              <Form.Item label="Salary">
                <InputNumber
                  value={newJob.salary}
                  onChange={value =>
                    setNewJob({ ...newJob, salary: value || 0 })
                  }
                />
              </Form.Item>
              <Form.Item label="Location">
                <Input
                  value={newJob.location}
                  onChange={e =>
                    setNewJob({ ...newJob, location: e.target.value })
                  }
                />
              </Form.Item>
              <Button
                type="primary"
                icon={<PlusOutlined />}
                onClick={handleCreateJob}
              >
                Post Job
              </Button>
            </Form>
          </Card>
        )}

        <Row gutter={[16, 16]}>
          {jobs?.map(job => (
            <Col xs={24} sm={12} md={8} key={job.id}>
              <Card
                title={job.title}
                extra={
                  <a onClick={() => router.push(`/jobs/${job.id}`)}>Details</a>
                }
              >
                <p>{job.description}</p>
                <p>Salary: ${job.salary?.toString()}</p>
                <p>Location: {job.location}</p>
                <p>Company: {job.company?.name}</p>
              </Card>
            </Col>
          ))}
        </Row>
      </Space>
    </PageLayout>
  )
}
