'use client'

import { Prisma } from '@prisma/client'
import { Typography, Spin, Button, Form, Input, InputNumber, Space } from 'antd'
import {
  EditOutlined,
  SaveOutlined,
  ArrowLeftOutlined,
} from '@ant-design/icons'
import { useState } from 'react'
const { Title, Paragraph } = Typography
import { useUserContext } from '@/core/context'
import { useRouter, useParams } from 'next/navigation'
import { useUploadPublic } from '@/core/hooks/upload'
import { useSnackbar } from 'notistack'
import dayjs from 'dayjs'
import { Api } from '@/core/trpc'
import { PageLayout } from '@/designSystem'

export default function JobDetailsPage() {
  const router = useRouter()
  const params = useParams<{ jobId: string }>()
  const { user } = useUserContext()
  const { enqueueSnackbar } = useSnackbar()
  const [isEditing, setIsEditing] = useState(false)

  const {
    data: job,
    isLoading,
    refetch,
  } = Api.job.findUnique.useQuery({
    where: { id: params.jobId },
    include: { company: true },
  })

  const { mutateAsync: updateJob } = Api.job.update.useMutation()

  const { mutateAsync: createApplication } =
    Api.application.create.useMutation()

  const { data: student } = Api.student.findFirst.useQuery({
    where: { userId: user?.id },
  })

  const handleEdit = () => {
    setIsEditing(true)
  }

  const handleSave = async (values: Prisma.JobUpdateInput) => {
    try {
      await updateJob({
        where: { id: params.jobId },
        data: values,
      })
      enqueueSnackbar('Job updated successfully', { variant: 'success' })
      setIsEditing(false)
      refetch()
    } catch (error) {
      enqueueSnackbar('Failed to update job', { variant: 'error' })
    }
  }

  const handleApply = async () => {
    if (!student) {
      enqueueSnackbar('Student profile not found', { variant: 'error' })
      return
    }
    try {
      await createApplication({
        data: {
          status: 'PENDING',
          applicationDate: new Date().toISOString(),
          job: { connect: { id: params.jobId } },
          student: { connect: { id: student.id } },
        },
      })
      enqueueSnackbar('Application submitted successfully', {
        variant: 'success',
      })
    } catch (error) {
      enqueueSnackbar('Failed to submit application', { variant: 'error' })
    }
  }

  const isRecruiter = user?.globalRole === 'RECRUITER'

  if (isLoading) {
    return (
      <PageLayout layout="narrow">
        <Spin size="large" />
      </PageLayout>
    )
  }

  if (!job) {
    return (
      <PageLayout layout="narrow">
        <Title level={2}>Job not found</Title>
      </PageLayout>
    )
  }

  return (
    <PageLayout layout="narrow">
      <Space direction="vertical" size="large" style={{ width: '100%' }}>
        <Button
          icon={<ArrowLeftOutlined />}
          onClick={() => router.push('/jobs')}
        >
          Back to Job Listings
        </Button>

        <Title level={2}>Job Details</Title>

        {isEditing ? (
          <Form initialValues={job} onFinish={handleSave} layout="vertical">
            <Form.Item
              name="title"
              label="Job Title"
              rules={[{ required: true }]}
            >
              <Input />
            </Form.Item>
            <Form.Item
              name="description"
              label="Description"
              rules={[{ required: true }]}
            >
              <Input.TextArea rows={4} />
            </Form.Item>
            <Form.Item
              name="salary"
              label="Salary"
              rules={[{ required: true }]}
            >
              <InputNumber style={{ width: '100%' }} />
            </Form.Item>
            <Form.Item
              name="location"
              label="Location"
              rules={[{ required: true }]}
            >
              <Input />
            </Form.Item>
            <Form.Item>
              <Button type="primary" htmlType="submit" icon={<SaveOutlined />}>
                Save
              </Button>
            </Form.Item>
          </Form>
        ) : (
          <>
            <Paragraph>
              <strong>Job Title:</strong> {job.title}
            </Paragraph>
            <Paragraph>
              <strong>Company:</strong> {job.company?.name}
            </Paragraph>
            <Paragraph>
              <strong>Description:</strong> {job.description}
            </Paragraph>
            <Paragraph>
              <strong>Salary:</strong> ${job.salary?.toString()}
            </Paragraph>
            <Paragraph>
              <strong>Location:</strong> {job.location}
            </Paragraph>

            {isRecruiter ? (
              <Button onClick={handleEdit} icon={<EditOutlined />}>
                Edit Job
              </Button>
            ) : (
              <Button onClick={handleApply} type="primary">
                Apply for this Job
              </Button>
            )}
          </>
        )}
      </Space>
    </PageLayout>
  )
}
