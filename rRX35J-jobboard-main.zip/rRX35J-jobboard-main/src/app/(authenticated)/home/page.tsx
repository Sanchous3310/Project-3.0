'use client'

import { Typography, Card, Row, Col, Statistic, List, Button } from 'antd'
import {
  UserOutlined,
  FileOutlined,
  DollarOutlined,
  EnvironmentOutlined,
} from '@ant-design/icons'
const { Title, Text } = Typography
import { useUserContext } from '@/core/context'
import { useRouter, useParams } from 'next/navigation'
import { useUploadPublic } from '@/core/hooks/upload'
import { useSnackbar } from 'notistack'
import dayjs from 'dayjs'
import { Api } from '@/core/trpc'
import { PageLayout } from '@/designSystem'

export default function HomePage() {
  const router = useRouter()
  const params = useParams<any>()
  const { user } = useUserContext()
  const { enqueueSnackbar } = useSnackbar()

  const { data: jobs, isLoading: jobsLoading } = Api.job.findMany.useQuery({
    include: { company: true },
  })

  const { data: applications, isLoading: applicationsLoading } =
    Api.application.findMany.useQuery({
      include: { job: true, student: { include: { user: true } } },
    })

  const isRecruiter = user?.globalRole === 'RECRUITER'

  const renderRecruiterDashboard = () => (
    <>
      <Title level={2}>Recruiter Dashboard</Title>
      <Row gutter={16}>
        <Col span={8}>
          <Card>
            <Statistic
              title="Total Job Openings"
              value={jobs?.length || 0}
              prefix={<FileOutlined />}
            />
          </Card>
        </Col>
        <Col span={8}>
          <Card>
            <Statistic
              title="Total Applicants"
              value={applications?.length || 0}
              prefix={<UserOutlined />}
            />
          </Card>
        </Col>
        <Col span={8}>
          <Card>
            <Statistic
              title="Average Salary"
              value={
                jobs?.reduce((acc, job) => acc + (job.salary || 0), 0) /
                (jobs?.length || 1)
              }
              precision={2}
              prefix={<DollarOutlined />}
            />
          </Card>
        </Col>
      </Row>
      <Title level={3} style={{ marginTop: '24px' }}>
        Recent Applications
      </Title>
      <List
        dataSource={applications?.slice(0, 5)}
        renderItem={application => (
          <List.Item>
            <List.Item.Meta
              title={application.job?.title}
              description={`Applicant: ${application.student?.user?.name} | Status: ${application.status}`}
            />
            <Text>
              {dayjs(application.applicationDate).format('MMMM D, YYYY')}
            </Text>
          </List.Item>
        )}
      />
    </>
  )

  const renderStudentJobListings = () => (
    <>
      <Title level={2}>Available Job Opportunities</Title>
      <List
        dataSource={jobs}
        renderItem={job => (
          <List.Item
            actions={[
              <Button
                key="apply"
                onClick={() => router.push(`/jobs/${job.id}`)}
              >
                View Details
              </Button>,
            ]}
          >
            <List.Item.Meta
              title={job.title}
              description={
                <>
                  <Text>
                    <DollarOutlined /> Salary: ${job.salary?.toString()}
                  </Text>
                  <br />
                  <Text>
                    <EnvironmentOutlined /> Location: {job.location}
                  </Text>
                </>
              }
            />
            <Text>{job.company?.name}</Text>
          </List.Item>
        )}
      />
    </>
  )

  if (jobsLoading || applicationsLoading) {
    return <PageLayout layout="narrow">Loading...</PageLayout>
  }

  return (
    <PageLayout layout="narrow">
      {isRecruiter ? renderRecruiterDashboard() : renderStudentJobListings()}
    </PageLayout>
  )
}
