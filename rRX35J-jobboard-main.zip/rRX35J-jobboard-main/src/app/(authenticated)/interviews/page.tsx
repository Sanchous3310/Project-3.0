'use client'

import {
  Typography,
  Card,
  List,
  Button,
  Modal,
  DatePicker,
  Input,
  Space,
} from 'antd'
import {
  CalendarOutlined,
  ClockCircleOutlined,
  EnvironmentOutlined,
} from '@ant-design/icons'
import { useState } from 'react'
const { Title, Text } = Typography
import { useUserContext } from '@/core/context'
import { useRouter, useParams } from 'next/navigation'
import { useUploadPublic } from '@/core/hooks/upload'
import { useSnackbar } from 'notistack'
import dayjs from 'dayjs'
import { Api } from '@/core/trpc'
import { PageLayout } from '@/designSystem'

export default function InterviewSchedulerPage() {
  const router = useRouter()
  const params = useParams<any>()
  const { user } = useUserContext()
  const { enqueueSnackbar } = useSnackbar()

  const [isModalVisible, setIsModalVisible] = useState(false)
  const [selectedInterview, setSelectedInterview] = useState<any>(null)
  const [newDateTime, setNewDateTime] = useState<any>(null)
  const [newLocation, setNewLocation] = useState('')

  const {
    data: interviews,
    isLoading,
    refetch,
  } = Api.interview.findMany.useQuery({
    where:
      user?.globalRole === 'RECRUITER'
        ? { recruiterId: user?.id }
        : { application: { studentId: user?.id } },
    include: {
      application: { include: { student: true, job: true } },
      recruiter: true,
    },
  })

  const { mutateAsync: updateInterview } = Api.interview.update.useMutation()

  const handleSchedule = async (interview: any) => {
    try {
      await updateInterview({
        where: { id: interview.id },
        data: { status: 'SCHEDULED' },
      })
      enqueueSnackbar('Interview scheduled successfully', {
        variant: 'success',
      })
      refetch()
    } catch (error) {
      enqueueSnackbar('Failed to schedule interview', { variant: 'error' })
    }
  }

  const handleConfirm = async (interview: any) => {
    try {
      await updateInterview({
        where: { id: interview.id },
        data: { status: 'CONFIRMED' },
      })
      enqueueSnackbar('Interview confirmed successfully', {
        variant: 'success',
      })
      refetch()
    } catch (error) {
      enqueueSnackbar('Failed to confirm interview', { variant: 'error' })
    }
  }

  const handleReschedule = (interview: any) => {
    setSelectedInterview(interview)
    setNewDateTime(dayjs(interview.dateTime))
    setNewLocation(interview.location || '')
    setIsModalVisible(true)
  }

  const handleRescheduleSubmit = async () => {
    if (!newDateTime || !newLocation) {
      enqueueSnackbar('Please fill all fields', { variant: 'error' })
      return
    }

    try {
      await updateInterview({
        where: { id: selectedInterview.id },
        data: {
          dateTime: newDateTime.toISOString(),
          location: newLocation,
          status: 'RESCHEDULED',
        },
      })
      enqueueSnackbar('Interview rescheduled successfully', {
        variant: 'success',
      })
      setIsModalVisible(false)
      refetch()
    } catch (error) {
      enqueueSnackbar('Failed to reschedule interview', { variant: 'error' })
    }
  }

  return (
    <PageLayout layout="narrow">
      <Title level={2}>Interview Scheduler</Title>
      <Text>Manage and schedule your interviews here.</Text>

      {isLoading ? (
        <Text>Loading interviews...</Text>
      ) : (
        <List
          dataSource={interviews}
          renderItem={(interview: any) => (
            <List.Item>
              <Card style={{ width: '100%' }}>
                <Title level={4}>
                  {user?.globalRole === 'RECRUITER'
                    ? `Interview with ${interview.application?.student?.user?.name}`
                    : `Interview for ${interview.application?.job?.title}`}
                </Title>
                <Space direction="vertical">
                  <Text>
                    <CalendarOutlined /> Date:{' '}
                    {dayjs(interview.dateTime).format('MMMM D, YYYY')}
                  </Text>
                  <Text>
                    <ClockCircleOutlined /> Time:{' '}
                    {dayjs(interview.dateTime).format('h:mm A')}
                  </Text>
                  <Text>
                    <EnvironmentOutlined /> Location: {interview.location}
                  </Text>
                  <Text>Status: {interview.status}</Text>
                </Space>
                <Space style={{ marginTop: '1rem' }}>
                  {user?.globalRole === 'RECRUITER' &&
                    interview.status === 'PENDING' && (
                      <Button onClick={() => handleSchedule(interview)}>
                        Schedule
                      </Button>
                    )}
                  {user?.globalRole === 'STUDENT' &&
                    interview.status === 'SCHEDULED' && (
                      <>
                        <Button onClick={() => handleConfirm(interview)}>
                          Confirm
                        </Button>
                        <Button onClick={() => handleReschedule(interview)}>
                          Reschedule
                        </Button>
                      </>
                    )}
                </Space>
              </Card>
            </List.Item>
          )}
        />
      )}

      <Modal
        title="Reschedule Interview"
        open={isModalVisible}
        onOk={handleRescheduleSubmit}
        onCancel={() => setIsModalVisible(false)}
      >
        <Space direction="vertical" style={{ width: '100%' }}>
          <DatePicker
            showTime
            value={newDateTime}
            onChange={value => setNewDateTime(value)}
            style={{ width: '100%' }}
          />
          <Input
            placeholder="New Location"
            value={newLocation}
            onChange={e => setNewLocation(e.target.value)}
          />
        </Space>
      </Modal>
    </PageLayout>
  )
}
