'use client'

import { Typography, Table, Tag, Space, Button } from 'antd'
import {
  FileSearchOutlined,
  CheckCircleOutlined,
  CloseCircleOutlined,
} from '@ant-design/icons'
const { Title, Text } = Typography
import { useUserContext } from '@/core/context'
import { useRouter, useParams } from 'next/navigation'
import { useUploadPublic } from '@/core/hooks/upload'
import { useSnackbar } from 'notistack'
import dayjs from 'dayjs'
import { Api } from '@/core/trpc'
import { PageLayout } from '@/designSystem'

export default function ApplicationTrackingPage() {
  const router = useRouter()
  const params = useParams<any>()
  const { user, checkRole } = useUserContext()
  const { enqueueSnackbar } = useSnackbar()

  const {
    data: applications,
    isLoading,
    refetch,
  } = Api.application.findMany.useQuery({
    where: checkRole?.('STUDENT') ? { studentId: user?.id } : {},
    include: { job: { include: { company: true } }, student: true },
  })

  const { mutateAsync: updateApplication } =
    Api.application.update.useMutation()

  const handleStatusChange = async (id: string, newStatus: string) => {
    try {
      await updateApplication({ where: { id }, data: { status: newStatus } })
      enqueueSnackbar('Application status updated successfully', {
        variant: 'success',
      })
      refetch()
    } catch (error) {
      enqueueSnackbar('Failed to update application status', {
        variant: 'error',
      })
    }
  }

  const columns = [
    {
      title: 'Job Title',
      dataIndex: ['job', 'title'],
      key: 'jobTitle',
    },
    {
      title: 'Company',
      dataIndex: ['job', 'company', 'name'],
      key: 'company',
    },
    {
      title: 'Application Date',
      dataIndex: 'applicationDate',
      key: 'applicationDate',
      render: (date: string) => dayjs(date).format('MMMM D, YYYY'),
    },
    {
      title: 'Status',
      dataIndex: 'status',
      key: 'status',
      render: (status: string) => (
        <Tag
          color={
            status === 'Pending'
              ? 'blue'
              : status === 'Accepted'
                ? 'green'
                : 'red'
          }
        >
          {status}
        </Tag>
      ),
    },
    {
      title: 'Actions',
      key: 'actions',
      render: (_: any, record: any) => (
        <Space size="middle">
          <Button
            icon={<FileSearchOutlined />}
            onClick={() => router.push(`/jobs/${record.job.id}`)}
          >
            View Job
          </Button>
          {checkRole?.('RECRUITER') && (
            <>
              <Button
                icon={<CheckCircleOutlined />}
                onClick={() => handleStatusChange(record.id, 'Accepted')}
                disabled={record.status === 'Accepted'}
              >
                Accept
              </Button>
              <Button
                icon={<CloseCircleOutlined />}
                onClick={() => handleStatusChange(record.id, 'Rejected')}
                disabled={record.status === 'Rejected'}
                danger
              >
                Reject
              </Button>
            </>
          )}
        </Space>
      ),
    },
  ]

  return (
    <PageLayout layout="narrow">
      <Title level={2}>Application Tracking</Title>
      <Text>
        {checkRole?.('STUDENT')
          ? 'View the status of your job applications'
          : 'Manage and review applications for each job posting'}
      </Text>
      <Table
        columns={columns}
        dataSource={applications}
        rowKey="id"
        loading={isLoading}
        style={{ marginTop: '20px' }}
        pagination={{ pageSize: 10 }}
      />
    </PageLayout>
  )
}
